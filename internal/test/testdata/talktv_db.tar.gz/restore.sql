--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.12 (Homebrew)
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE talktv;
--
-- Name: talktv; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE talktv WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE talktv OWNER TO postgres;

\connect talktv

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: dustysaker
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO dustysaker;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: languages; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.languages (
    id bigint NOT NULL,
    language text NOT NULL,
    tag text NOT NULL
);


ALTER TABLE public.languages OWNER TO talktv;

--
-- Name: languages_id_seq; Type: SEQUENCE; Schema: public; Owner: talktv
--

CREATE SEQUENCE public.languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.languages_id_seq OWNER TO talktv;

--
-- Name: languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: talktv
--

ALTER SEQUENCE public.languages_id_seq OWNED BY public.languages.id;


--
-- Name: movies; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.movies (
    id bigint NOT NULL,
    title text NOT NULL,
    num_subs integer NOT NULL,
    language_id bigint DEFAULT 0 NOT NULL,
    mp3 boolean DEFAULT false
);


ALTER TABLE public.movies OWNER TO talktv;

--
-- Name: movies_id_seq; Type: SEQUENCE; Schema: public; Owner: talktv
--

CREATE SEQUENCE public.movies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movies_id_seq OWNER TO talktv;

--
-- Name: movies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: talktv
--

ALTER SEQUENCE public.movies_id_seq OWNED BY public.movies.id;


--
-- Name: phrases; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.phrases (
    id bigint NOT NULL,
    movie_id bigint NOT NULL,
    phrase text NOT NULL,
    translates text NOT NULL,
    phrase_hint text NOT NULL,
    translates_hint text NOT NULL
);


ALTER TABLE public.phrases OWNER TO talktv;

--
-- Name: phrases_id_seq; Type: SEQUENCE; Schema: public; Owner: talktv
--

CREATE SEQUENCE public.phrases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.phrases_id_seq OWNER TO talktv;

--
-- Name: phrases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: talktv
--

ALTER SEQUENCE public.phrases_id_seq OWNED BY public.phrases.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO talktv;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.sessions (
    token text NOT NULL,
    data bytea NOT NULL,
    expiry timestamp with time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO talktv;

--
-- Name: tokens; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.tokens (
    hash bytea NOT NULL,
    user_id bigint NOT NULL,
    expiry timestamp(0) with time zone NOT NULL,
    scope text NOT NULL
);


ALTER TABLE public.tokens OWNER TO talktv;

--
-- Name: users; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    movie_id bigint NOT NULL,
    name text NOT NULL,
    email public.citext NOT NULL,
    hashed_password bytea NOT NULL,
    flipped boolean DEFAULT false NOT NULL,
    created timestamp(0) without time zone DEFAULT now() NOT NULL,
    language_id bigint DEFAULT 0 NOT NULL,
    activated boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.users OWNER TO talktv;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: talktv
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO talktv;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: talktv
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users_phrases; Type: TABLE; Schema: public; Owner: talktv
--

CREATE TABLE public.users_phrases (
    user_id bigint NOT NULL,
    phrase_id bigint NOT NULL,
    movie_id bigint NOT NULL,
    phrase_correct bigint,
    flipped_correct bigint
);


ALTER TABLE public.users_phrases OWNER TO talktv;

--
-- Name: languages id; Type: DEFAULT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.languages ALTER COLUMN id SET DEFAULT nextval('public.languages_id_seq'::regclass);


--
-- Name: movies id; Type: DEFAULT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.movies ALTER COLUMN id SET DEFAULT nextval('public.movies_id_seq'::regclass);


--
-- Name: phrases id; Type: DEFAULT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.phrases ALTER COLUMN id SET DEFAULT nextval('public.phrases_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.languages (id, language, tag) FROM stdin;
\.
COPY public.languages (id, language, tag) FROM '$$PATH$$/3813.dat';

--
-- Data for Name: movies; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.movies (id, title, num_subs, language_id, mp3) FROM stdin;
\.
COPY public.movies (id, title, num_subs, language_id, mp3) FROM '$$PATH$$/3805.dat';

--
-- Data for Name: phrases; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.phrases (id, movie_id, phrase, translates, phrase_hint, translates_hint) FROM stdin;
\.
COPY public.phrases (id, movie_id, phrase, translates, phrase_hint, translates_hint) FROM '$$PATH$$/3809.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.schema_migrations (version, dirty) FROM stdin;
\.
COPY public.schema_migrations (version, dirty) FROM '$$PATH$$/3803.dat';

--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.sessions (token, data, expiry) FROM stdin;
\.
COPY public.sessions (token, data, expiry) FROM '$$PATH$$/3810.dat';

--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.tokens (hash, user_id, expiry, scope) FROM stdin;
\.
COPY public.tokens (hash, user_id, expiry, scope) FROM '$$PATH$$/3814.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.users (id, movie_id, name, email, hashed_password, flipped, created, language_id, activated, version) FROM stdin;
\.
COPY public.users (id, movie_id, name, email, hashed_password, flipped, created, language_id, activated, version) FROM '$$PATH$$/3807.dat';

--
-- Data for Name: users_phrases; Type: TABLE DATA; Schema: public; Owner: talktv
--

COPY public.users_phrases (user_id, phrase_id, movie_id, phrase_correct, flipped_correct) FROM stdin;
\.
COPY public.users_phrases (user_id, phrase_id, movie_id, phrase_correct, flipped_correct) FROM '$$PATH$$/3811.dat';

--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: talktv
--

SELECT pg_catalog.setval('public.languages_id_seq', 133, true);


--
-- Name: movies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: talktv
--

SELECT pg_catalog.setval('public.movies_id_seq', 2, true);


--
-- Name: phrases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: talktv
--

SELECT pg_catalog.setval('public.phrases_id_seq', 40, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: talktv
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: movies movies_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.movies
    ADD CONSTRAINT movies_pkey PRIMARY KEY (id);


--
-- Name: phrases phrases_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.phrases
    ADD CONSTRAINT phrases_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (token);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (hash);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_name_unique_key; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_name_unique_key UNIQUE (name);


--
-- Name: users_phrases users_phrases_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users_phrases
    ADD CONSTRAINT users_phrases_pkey PRIMARY KEY (user_id, phrase_id, movie_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: movies_title_trgm_idx; Type: INDEX; Schema: public; Owner: talktv
--

CREATE INDEX movies_title_trgm_idx ON public.movies USING gist (title public.gist_trgm_ops);


--
-- Name: sessions_expiry_idx; Type: INDEX; Schema: public; Owner: talktv
--

CREATE INDEX sessions_expiry_idx ON public.sessions USING btree (expiry);


--
-- Name: movies movies_language_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.movies
    ADD CONSTRAINT movies_language_id_fkey FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: phrases phrases_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.phrases
    ADD CONSTRAINT phrases_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES public.movies(id);


--
-- Name: tokens tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_language_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_language_id_fkey FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: users users_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES public.movies(id);


--
-- Name: users_phrases users_phrases_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users_phrases
    ADD CONSTRAINT users_phrases_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES public.movies(id);


--
-- Name: users_phrases users_phrases_phrase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users_phrases
    ADD CONSTRAINT users_phrases_phrase_id_fkey FOREIGN KEY (phrase_id) REFERENCES public.phrases(id);


--
-- Name: users_phrases users_phrases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: talktv
--

ALTER TABLE ONLY public.users_phrases
    ADD CONSTRAINT users_phrases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: dustysaker
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

